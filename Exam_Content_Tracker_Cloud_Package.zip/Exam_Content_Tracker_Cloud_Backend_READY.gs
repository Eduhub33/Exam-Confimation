/**
 * Exam Content Tracker - Google Apps Script cloud backend
 *
 * 1. Create a new Google Apps Script project.
 * 2. Paste this entire file into Code.gs.
 * 3. Change CLOUD_TOKEN to a long private value.
 * 4. Deploy > New deployment > Web app.
 *    Execute as: Me
 *    Who has access: Anyone
 * 5. Copy the /exec URL into CLOUD_SYNC_URL in the HTML.
 * 6. Put the same token into CLOUD_SYNC_TOKEN in the HTML.
 *
 * This stores the tracker as one JSON dataset in Script Properties.
 * Suitable for a small internal tracker. For high-security/multi-user
 * production use, use a real database + authentication instead.
 */

const CLOUD_TOKEN = '8Yh3jx42Ni5fdBzhDbQ0MU7bqP4sEod8';
const DATA_KEY = 'EXAM_CONTENT_TRACKER_DATA_V1';

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function authorised_(token) {
  return token && token === CLOUD_TOKEN;
}

function doGet(e) {
  const token = e && e.parameter ? e.parameter.token : '';
  if (!authorised_(token)) return json_({ok:false, message:'Unauthorized'});

  const raw = PropertiesService.getScriptProperties().getProperty(DATA_KEY);
  let data = [];
  if (raw) {
    try { data = JSON.parse(raw); } catch (_) { data = []; }
  }
  return json_({ok:true, data:data, updatedAt:new Date().toISOString()});
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!authorised_(body.token)) return json_({ok:false, message:'Unauthorized'});
    if (!Array.isArray(body.data)) return json_({ok:false, message:'Invalid data'});

    const lock = LockService.getScriptLock();
    lock.waitLock(10000);
    try {
      PropertiesService.getScriptProperties().setProperty(DATA_KEY, JSON.stringify(body.data));
    } finally {
      lock.releaseLock();
    }
    return json_({ok:true, saved:body.data.length, updatedAt:new Date().toISOString()});
  } catch (err) {
    return json_({ok:false, message:String(err)});
  }
}
